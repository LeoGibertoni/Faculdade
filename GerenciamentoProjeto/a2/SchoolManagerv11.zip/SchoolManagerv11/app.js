(function(){
  const dbKey = "schoolmanager_db_v5";
  const initialData = {
    users: [
      { id: "u1", role: "admin", name: "Admin Master", email: "admin@school.local", password: "admin123" },
      { id: "u2", role: "prof", name: "Prof. Ana", email: "ana@school.local", password: "prof123", disciplinaId: "d1" },
      { id: "u3", role: "aluno", name: "Carlos Silva", email: "carlos@school.local", password: "aluno123" }
    ],
    turmas: [
      { id: "t1", nome: "1ºA", ano: 2025, turno: "Manhã" },
      { id: "t2", nome: "2ºB", ano: 2025, turno: "Tarde" }
    ],
    disciplinas: [
      { id: "d1", nome: "Matemática" },
      { id: "d2", nome: "Português" },
      { id: "d3", nome: "História" }
    ],
    vinculacoes: [],
    matriculas: [{ id:"m1", alunoId:"u3", turmaId:"t1" }],
    notas: [], presencas: [],
    comunicados: [{ id: "c1", autorId: "u2", titulo: "Bem-vindos!", corpo: "Aulas começam dia 05/02.", dataISO: new Date().toISOString() }],
    session: null
  };

  function getDB(){
    const raw = localStorage.getItem(dbKey);
    if(!raw){ localStorage.setItem(dbKey, JSON.stringify(initialData)); return JSON.parse(JSON.stringify(initialData)); }
    try{ return JSON.parse(raw); } catch(e){ localStorage.setItem(dbKey, JSON.stringify(initialData)); return JSON.parse(JSON.stringify(initialData)); }
  }
  function setDB(db){ localStorage.setItem(dbKey, JSON.stringify(db)); }
  function uid(p){ return p+Math.random().toString(16).slice(2); }

  const A = {
    resetDB(){ localStorage.removeItem(dbKey); getDB(); },
    signIn(email, password){
      const db=getDB();
      const u=db.users.find(x=>x.email===email && x.password===password);
      if(!u) return null;
      db.session={ userId:u.id, ts:Date.now() };
      setDB(db); return u;
    },
    signOut(){ const db=getDB(); db.session=null; setDB(db); },
    currentUser(){ const db=getDB(); if(!db.session) return null; return db.users.find(u=>u.id===db.session.userId)||null; },
    listUsers(){ return getDB().users; },
    getTurmaOfAluno(alunoId){
      const db=getDB(); const m=db.matriculas.find(x=>x.alunoId===alunoId); return m? m.turmaId : null;
    },
    alunosByTurma(turmaId){
      const db=getDB();
      const alunosIds = db.matriculas.filter(m=>m.turmaId===turmaId).map(m=>m.alunoId);
      return db.users.filter(u=>u.role==='aluno' && alunosIds.includes(u.id));
    },
    createUser(u){
      const db=getDB(); u.id=uid('u'); db.users.push(u);
      // se for aluno com turmaId, cria matrícula
      if(u.role==='aluno' && u.turmaId){
        db.matriculas.push({ id: uid('m'), alunoId: u.id, turmaId: u.turmaId });
      }
      setDB(db); return u;
    },
    updateUser(id, patch){
      const db=getDB(); const i=db.users.findIndex(u=>u.id===id); if(i<0) return null;
      const prev=db.users[i];
      db.users[i]={...prev, ...patch};
      // se mudarem a turma do aluno, atualiza matrícula (simples: 1-para-1)
      if(db.users[i].role==='aluno' && patch.turmaId!==undefined){
        const mIdx = db.matriculas.findIndex(m=>m.alunoId===id);
        if(mIdx>=0) db.matriculas[mIdx].turmaId = patch.turmaId;
        else db.matriculas.push({ id: uid('m'), alunoId: id, turmaId: patch.turmaId });
      }
      setDB(db); return db.users[i];
    },
    deleteUser(id){ const db=getDB(); db.users=db.users.filter(u=>u.id!==id);
      db.matriculas=db.matriculas.filter(m=>m.alunoId!==id);
      db.notas=db.notas.filter(n=>n.alunoId!==id && n.profId!==id);
      db.presencas=db.presencas.filter(p=>p.alunoId!==id && p.profId!==id);
      setDB(db);
    },
    turmas: { list(){ return getDB().turmas; },
      create(t){ const db=getDB(); t.id=uid('t'); db.turmas.push(t); setDB(db); return t; },
      remove(id){ const db=getDB(); db.turmas=db.turmas.filter(t=>t.id!==id); db.matriculas=db.matriculas.filter(m=>m.turmaId!==id); setDB(db); } },
    disciplinas: { list(){ return getDB().disciplinas; },
      create(d){ const db=getDB(); d.id=uid('d'); db.disciplinas.push(d); setDB(db); return d; },
      remove(id){ const db=getDB(); db.disciplinas=db.disciplinas.filter(d=>d.id!==id);
        // limpar materia de professores
        db.users=db.users.map(u=> u.role==='prof' && u.disciplinaId===id ? {...u, disciplinaId:undefined} : u);
        setDB(db);
      } },
    matriculas: { list(){ return getDB().matriculas; } },
    notas: {
      list(){ return getDB().notas; },
      create(n){ const db=getDB(); n.id=uid('n'); db.notas.push(n); setDB(db); return n; },
      listByAluno(id){ return getDB().notas.filter(n=>n.alunoId===id); }
    },
    presencas: {
      list(){ return getDB().presencas; },
      marcarBatch(lista){ // [{alunoId, turmaId, disciplinaId, dataISO, status}]
        const db=getDB();
        for(const p of lista){ db.presencas.push({ id:uid('p'), ...p }); }
        setDB(db);
      },
      marcar(p){ const db=getDB(); p.id=uid('p'); db.presencas.push(p); setDB(db); return p; },
      listByAluno(id){ return getDB().presencas.filter(p=>p.alunoId===id); },
      resumoPorDisciplina(alunoId){
        const db=getDB();
        const porDisc = {};
        for(const p of db.presencas.filter(x=>x.alunoId===alunoId)){
          if(!porDisc[p.disciplinaId]) porDisc[p.disciplinaId]={P:0,F:0,total:0};
          if(p.status==='P') porDisc[p.disciplinaId].P++; else porDisc[p.disciplinaId].F++;
          porDisc[p.disciplinaId].total++;
        }
        return porDisc;
      }
    },
    comunicados: { list(){ return getDB().comunicados.sort((a,b)=>new Date(b.dataISO)-new Date(a.dataISO)); },
      publicar(c){ const db=getDB(); c.id=uid('c'); c.dataISO=new Date().toISOString(); db.comunicados.push(c); setDB(db); return c; } },

    // UI helpers
    guard(roles){
      const u=A.currentUser();
      if(!u){ location.href='index.html'; return; }
      if(roles && !roles.includes(u.role)){ alert('Acesso negado.'); location.href='index.html'; }
    },
    headerHTML(){
      const u=A.currentUser();
      const roleName = u ? (u.role==='admin'?'Administrador':u.role==='prof'?'Professor':'Aluno') : '';
      const menus = {
        admin:[['admin.html','Dashboard'],['usuarios.html','Usuários'],['turmas.html','Turmas'],['disciplinas.html','Disciplinas'],['comunicados.html','Comunicados']],
        prof:[['professor.html','Dashboard'],['notas.html','Notas'],['presencas.html','Presenças'],['comunicados.html','Comunicados']],
        aluno:[['aluno.html','Minha Área'],['notas.html','Minhas Notas'],['presencas.html','Minhas Presenças'],['comunicados.html','Comunicados']]
      };
      const nav = u ? (menus[u.role]||[]) : [];
      return `<header class="header"><div class="nav container">
        <div class="brand"><span class="logo"></span><span>SchoolManager</span></div>
        <nav style="display:flex;gap:10px;flex-wrap:wrap">
          ${nav.map(([h,l])=>`<a class="btn ghost" href="${h}">${l}</a>`).join('')}
        </nav>
        <div style="display:flex;align-items:center;gap:10px">
          ${u? `<div style="text-align:right"><div style="font-weight:600">${u.name}</div><div style="font-size:12px">${roleName}</div></div>`:''}
          ${u? `<button class="btn secondary" id="logoutBtn">Sair</button>`:`<a class="btn" href="index.html">Entrar</a>`}
        </div>
      </div></header>`;
    },
    mountHeader(){
      const hdr=document.getElementById('hdr');
      if(hdr){ hdr.innerHTML=A.headerHTML(); const b=document.getElementById('logoutBtn'); if(b) b.onclick=()=>{A.signOut(); location.href='index.html';}; }
    }
  };

  window.App = A;
})();
